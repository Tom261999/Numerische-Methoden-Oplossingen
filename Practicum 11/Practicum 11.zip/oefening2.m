clear, close all

for i = 1:6
    findiffho(i)
    pause(1)
end
clear i

%Wat de plots geeft die gevraagd werden. Ook kan men duidelijk zien dat de
%energie steeds eindigd in .5, wat een logisch gevolg is uit de theorie van
%kwantummechanica.