clear, close all

for i = 1:6
    findiff(i)
    pause(1)
end
clear i

% We zien dat de eigenwaarden van de hamiltoniaan de eigenfuncties geven 
% voor een deeltje in een doos met lengte L.