%deel 1 
dftcsfuncNeumann(10^-4,61,1,1,300)
%hier werd de dfcts aangepast om gebruik te maken van de Neumann
%randvoorwaarden.

%deel 2
dftcsfuncNeumannmod(10^-4,61,1,1,300)
%hier werd de dfcts aangepast om gebruik te maken van de Neumann
%randvoorwaarden en voorde BVW dat de deltafunctie geplaatst is op L/4
