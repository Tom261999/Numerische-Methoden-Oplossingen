clear, close all
dftcsmod
pause(10)
dftcsmod2
%Met de Neumann randvoorwaarden zien we dat onze temperaturen zich meer
%"vloeiend" gedragen wat intuitief ook logischer is. Zeker wanneer we de
%deltapiek dichter bij een rand plaatsen is het logischer dat deze rand mee
%zal opwarmen en daarna de temperatuur ook zal uitdijen en zich verspreiden
%over de hele ruimte.