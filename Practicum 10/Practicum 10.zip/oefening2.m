clear, close all
funcshroalt2(2000,0.1)
%Wat de gevraagde plots geeft