clear, close all

for U = 0.1:0.4:1.6
    funcshrodelta(U)
end

%We zien dat er een klein deel van de golf gereflecteerd wordt, waardoor
%onze waarschijnlijkheidsdichteheden interferentiegedrag vertonen. We zien
%tevens dat voor een potentiaal groter dan de energie van de golf de
%amplitude van de teruglopende golf groter is (waardoor de interferentie
%duidelijker is) dan voor een potentiaal die kleiner is dan de energie van
%de golf.