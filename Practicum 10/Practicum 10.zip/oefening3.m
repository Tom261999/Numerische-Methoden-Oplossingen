clear, close all
funcshroalt3(2000,0.1,1) %Grondtoestand
pause(5)
funcshroalt3(2000,0.1,2) %Eerste geexciteerde toestand
%Wat de gevraagde plots geeft