clear, close all

%We tonen het script voor enkele potentialen en barriere dikten en
%locaties:

shropotentiaal(0.1,750,50)
shropotentiaal(1,750,50)
shropotentiaal(2,750,50)
shropotentiaal(1,550,50)
shropotentiaal(1,550,300)
