%Een voorbeeld van functie funcalpha(c,A,d) met c,d vectoren en A een
%matrix.

c = randn(5,1)
A = randn(5,5)
d = randn(5,1)

alpha = funcalpha(c,A,d);