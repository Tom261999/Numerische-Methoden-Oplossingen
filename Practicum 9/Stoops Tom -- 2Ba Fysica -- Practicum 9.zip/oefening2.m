%Jacobi methode
relax_cirkel(1)
pause(7)
%Gauss-Seidel methode
relax_cirkel(2)
pause(7)
%SOR methode voor omega = 1.5 (zelf gekozen, niet geoptimaliseerd)
relax_cirkel(3)