%Run het script relaxmod.m voor de verschillende methoden om de gevraagde
%resultaten te verkrijgen.

%Met de gekozen beginvoorwaarde lijkt de Jacobi-methode het snelst te
%convergeren naar de oplossing, maar als we beginvoorwaarde 0 gebruiken
%zal Gauss-Seidel sneller convergeren (Of SOR met optimale omega)