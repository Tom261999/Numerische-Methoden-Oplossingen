%Run het script relax_cirkel.m voor de verschillende methoden om de 
%gevraagde resultaten te verkrijgen.